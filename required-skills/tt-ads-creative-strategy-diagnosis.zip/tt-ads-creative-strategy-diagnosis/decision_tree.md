# TikTok Ads Creative Strategy Diagnosis Skill

## 1. Skill 概述
该 Skill 用于把“广告目标 → 数据判断 → 创意策略 → 可执行脚本”的过程标准化，并接入 TikTok Ads MCP，在客户调用时优先读取客户广告账户、活动、广告、素材与表现数据，输出更精准的创意诊断与生成结果。

## 2. MCP 选型结论
### 推荐接入
- `tt-ads-mcp-layer`
- URL: `https://business-api.tiktok.com/open_mcp/tt-ads-mcp-layer`

### 选择原因
1. 更适配分层业务诊断：advertiser / campaign / adgroup / ad / creative / video。
2. 更适配本 Skill 原始文档中的 campaign_id、adgroup_id、ad_id、creative_id、video_id 分层字段。
3. 更利于后续在 Skill 内做“账户级 → 计划级 → 素材级”的逐层归因与决策。
4. 更利于把高层业务目标与底层素材表现关联起来。

### 兼容策略
- 当调用环境仅支持扁平结构时，再兼容 `tt-ads-mcp-flat`
- URL: `https://business-api.tiktok.com/open_mcp/tt-ads-mcp-flat`

## 3. 业务决策树梳理

### 3.1 主决策树
```text
START
├─ 1. 校验输入字段
│  ├─ 缺 advertiser_id 且用户需要账户数据 → 追问 advertiser_id
│  ├─ 缺 objective → 追问 objective
│  ├─ 缺 product_name / product_category / selling_points → 追问产品信息
│  └─ 字段完整 → 进入目标判断
│
├─ 2. 判断 objective
│  ├─ TRAFFIC / CLICK → CTR 创意树
│  ├─ CONVERSIONS → CVR 创意树
│  ├─ PRODUCT_SALES / GMV_MAX → GMV / ROAS 创意树
│  ├─ REACH → Reach 创意树
│  ├─ BRAND_AWARENESS → 品牌认知创意树
│  └─ 未知 → 通用创意树
│
├─ 3. 判断是否有 historical_creatives
│  ├─ 有 → 拆解历史成功素材
│  └─ 无 → 使用 objective 通用模板
│
├─ 4. 判断是否有 highlight_frame_signals / dropoff_signals
│  ├─ 有 → 执行高光帧诊断
│  └─ 无 → 使用 metrics + 目标模板生成
│
├─ 5. 判断是否需要 reference_source
│  ├─ TOP_ADS → 按 region / objective / ad_language / ad_format / category 提取借鉴方向
│  ├─ COMPETITOR → 拆解竞品 Hook / 展示 / CTA / 品牌资产
│  └─ 无 → 直接生成创意方案
│
└─ 6. 输出结构化结果
   ├─ objective_diagnosis
   ├─ creative_strategy
   ├─ creative_direction
   ├─ hook_candidates
   ├─ script_outline
   ├─ scene_plan
   ├─ product_demo_plan
   ├─ cta_plan
   ├─ brand_asset_plan
   ├─ reference_template
   ├─ variation_plan
   ├─ optimization_actions
   ├─ production_checklist
   └─ compliance_notes
```

### 3.2 子决策树

#### CTR 创意树
- 触发：objective = TRAFFIC / CLICK
- 重点：提升前 3 秒吸引力
- 规则：
  - ctr 低 → 重写 Hook，强化痛点/结果/价格/反差
  - ctr_peak_time > 5s → 将点击高光前置到 0-3s
  - dropoff_time < 3s → 前 1 秒出现产品或痛点

#### CVR 创意树
- 触发：objective = CONVERSIONS
- 重点：购买理由、信任证明、优惠前移
- 规则：
  - cvr 低 → 增加证明、评价、利益点
  - cvr_peak_time > 10s → 转化证明前移到 3-8s
  - ctr 高 cvr 低 → 保留 Hook，重写中后段转化链路

#### CPA 创意树
- 触发：cpa 高
- 重点：缩窄人群、减少泛点击
- 规则：
  - target_audience 不清晰 → 追问或自动拆分
  - 点击多订单少 → 强化适配场景与门槛

#### ROAS / GMV 创意树
- 触发：objective = PRODUCT_SALES / GMV_MAX
- 重点：价值证明、套装、复购、多件购
- 规则：
  - roas 低 → 强化价值证明与信任背书
  - 有转化但 GMV 不高 → 突出 bundle、save more、复购场景

#### Reach / Branding 创意树
- Reach：强视觉、情绪共鸣、轻 CTA
- Brand Awareness：Logo、品牌色、包装、口号一致性
- 品牌弱：先证明产品有用，再后置品牌
- 品牌强：前段可自然露出品牌元素

### 3.3 高光帧诊断树
```text
IF highlight_frame_signals 为空:
    使用 metrics + objective 生成通用创意
ELSE:
    IF ctr_peak_count < 2 OR cvr_peak_count < 2:
        问题 = 高光帧数量少
        动作 = 增加痛点、卖点、场景、价格、评价等多个触发点

    IF ctr_peak_time > 5s:
        问题 = CTR 高光帧后置
        动作 = 将点击高光内容前置到 0-3 秒

    IF cvr_peak_time > 10s:
        问题 = CVR 高光帧后置
        动作 = 将转化证明、优惠、效果展示提前到 3-8 秒

    IF dropoff_time < 3s:
        问题 = 流失过早
        动作 = 重写开头，前 1 秒出现产品或痛点

    IF ctr 高 AND cvr 低:
        问题 = 吸引强但转化弱
        动作 = 保留 Hook，重写产品证明、优惠和 CTA

    IF cvr 高 AND impressions 低:
        问题 = 转化强但流量弱
        动作 = 把转化高光内容前置为新 Hook
```

## 4. MCP 字段映射方案

### 4.1 统一输入 Schema
```json
{
  "advertiser_id": "string",
  "campaign_id": "string",
  "adgroup_id": "string",
  "ad_id": "string",
  "creative_id": "string",
  "video_id": "string",
  "objective": "string",
  "region": "string",
  "ad_language": "string",
  "ad_format": "string",
  "product_name": "string",
  "product_category": "string",
  "target_audience": "string|array",
  "selling_points": ["string"],
  "offer_info": "string",
  "metrics": {
    "ctr": "number|null",
    "cvr": "number|null",
    "cpa": "number|null",
    "roas": "number|null",
    "spend": "number|null",
    "conversions": "number|null",
    "impressions": "number|null",
    "clicks": "number|null",
    "likes": "number|null",
    "comments": "number|null",
    "shares": "number|null",
    "avg_watch_rate": "number|null",
    "fan_like_ratio": "number|null"
  },
  "historical_creatives": "string|array|null",
  "highlight_frame_signals": {
    "ctr_peak_time": "number|null",
    "ctr_peak_count": "number|null",
    "cvr_peak_time": "number|null",
    "cvr_peak_count": "number|null"
  },
  "dropoff_signals": {
    "dropoff_time": "number|null"
  },
  "reference_source": "string|null",
  "brand_guidelines": "string|null",
  "video_duration": "string|null",
  "output_type": "string|null"
}
```

### 4.2 旧字段映射
| 旧字段名 | MCP-Friendly 字段名 | 说明 |
|---|---|---|
| campaign_goal | objective | 广告目标 |
| language | ad_language | 广告语言 |
| key_selling_points | selling_points | 核心卖点 |
| successful_creative_summary | historical_creatives | 历史成功素材 |
| top_creative_metrics | metrics | 统一指标对象 |
| highlight_frame_notes | highlight_frame_signals | 高光帧信号 |
| dropoff_frame_notes | dropoff_signals | 流失帧信号 |
| competitor_reference | reference_source | 参考来源 |
| creative_strategy_summary | creative_strategy | 整体策略输出 |
| goal_diagnosis | objective_diagnosis | 目标诊断 |
| hook_options | hook_candidates | Hook 候选 |
| script_options | script_outline | 脚本结构 |
| storyboard | scene_plan | 分镜计划 |
| product_showcase_plan | product_demo_plan | 产品展示 |
| cta_options | cta_plan | CTA 方案 |
| brand_asset_usage | brand_asset_plan | 品牌资产 |
| creative_variations | variation_plan | 变体计划 |

### 4.3 面向 tt-ads-mcp-layer 的消费映射
| MCP层级 | 可能字段 | Skill统一字段 | 处理规则 |
|---|---|---|---|
| advertiser | id / advertiser_id | advertiser_id | 直接映射 |
| campaign | id / campaign_id | campaign_id | 直接映射 |
| campaign | objective / marketing_goal | objective | 枚举标准化 |
| adgroup | id / adgroup_id | adgroup_id | 直接映射 |
| ad | id / ad_id | ad_id | 直接映射 |
| creative | id / creative_id | creative_id | 直接映射 |
| video | id / video_id | video_id | 直接映射 |
| performance | ctr / click_through_rate | metrics.ctr | 数值化 |
| performance | cvr / conversion_rate | metrics.cvr | 数值化 |
| performance | cpa / cost_per_action | metrics.cpa | 数值化 |
| performance | roas / purchase_roas | metrics.roas | 数值化 |
| performance | spend / cost | metrics.spend | 数值化 |
| performance | conversions / purchase | metrics.conversions | 数值化 |
| performance | impressions | metrics.impressions | 数值化 |
| performance | clicks | metrics.clicks | 数值化 |
| creative summary | best performer list / top creative summary | historical_creatives | 摘要归一 |
| video analysis | peak frames / retention points | highlight_frame_signals / dropoff_signals | 若存在则映射，不存在则留空 |

## 5. Skill 输出结构
Skill 输出采用统一 JSON：
- objective_diagnosis
- creative_strategy
- creative_direction
- hook_candidates
- script_outline
- scene_plan
- product_demo_plan
- cta_plan
- brand_asset_plan
- reference_template
- variation_plan
- optimization_actions
- production_checklist
- compliance_notes

## 6. 产运视角补充要求
1. 优先少追问：能从 MCP 读到的字段，优先读，不让客户重复填。
2. 强约束输出：所有建议必须与 objective、metrics、素材问题形成因果链。
3. 对缺失字段容错：没有高光帧和流失帧时，不阻塞主输出。
4. 对 schema 兼容：真实 MCP schema 到位后，只替换映射层，不重做决策树。
5. 风险控制：不能复制竞品内容，不能夸大功效，不能虚构数据。

## 7. Skill 包内文件说明
- `SKILL.md`：Skill 主文件，可直接用于创建 Skill
- `decision_tree.md`：业务决策树与字段映射说明

## 8. 使用建议
创建 Skill 时直接上传 zip 包；后续若拿到真实 MCP schema，可仅更新 `SKILL.md` 中“消费映射规则”和“枚举值标准化”部分。
