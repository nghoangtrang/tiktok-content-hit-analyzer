# Creative feature boundaries

Use only when a requested creative plan includes one of these product features. These are dated public help constraints, not account eligibility or proof of an API/MCP connection. Recheck relevant current help via T3 before prescribing a manual path; if unavailable, mark unconfirmed and complete other supported work. Do not convert a documentation example into permission to publish, upload, or create a campaign.

## Automate Creative

Public help checked 2026-09-21, updated April 2026: https://ads.tiktok.com/help/article/about-automate-creative

The documented feature is selected during new-campaign ad creation. API and platform split testing are unsupported. Once published, its enablement and feature choices cannot be changed; a different configuration requires a new campaign. This skill neither creates that campaign nor presents it as a cost-free workaround. Offer keep-current/do-not-use as valid choices and disclose the implications of a separately authorized manual creation plan.

Documented objectives are reach, traffic, video views, community interaction, app promotion, web conversion and lead generation. Automatic placement lists TikTok, Pangle and Global App Bundle; selected placement lists TikTok. Formats include non-Spark video/carousel and push Spark. Rollout and actual settings still matter; global region support does not guarantee a toggle for this advertiser. Do not treat a missing toggle as a proven account defect.

A small manual comparison of creatives is not the platform Split Test feature and does not establish causal lift. Do not recommend the unsupported Split Test/API route for this feature.

## Generate with AI

Public help checked 2026-09-21, updated June 2025: https://ads.tiktok.com/help/article/about-generate-with-ai-in-tiktok-ads-manager?lang=en

Availability is selective and documented for product-sales and Smart+ Web objectives, with English content and at most one product per input URL. Product ID, URL or manual details can supply input. The platform may suggest up to ten generated candidates; customers can adjust the selection. This is not a requirement to produce or test ten variants, proof of video generation in this skill, or a promise of account access. Keep factual/rights review before use. Missing access does not prevent a text draft from approved customer facts.

## Catalog carousel editor

Public help checked 2026-09-21, updated April 2026: https://ads.tiktok.com/help/article/how-to-use-the-catalog-carousel-editor

The documented manual path is at ad details after campaign and ad-group creation: Use catalog creative → Catalog carousel / Advanced → Edit/change template. Background, text and stickers can be customized before the operator confirms. This describes UI behavior, not an API contract or permission to upload or apply edits. If the account UI differs, mark the path to confirm rather than inventing settings.
