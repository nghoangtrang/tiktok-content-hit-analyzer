# Decision rules

## C1 — Review quantity and quality together
For APAC creative review, consider the known supply of usable variants alongside measured performance. Delivered-ad coverage is not a complete library inventory. Do not infer that more material or more spend solves a measured problem.
Count unique assets only when their IDs and associations are explicit. An ad can contain several assets and an asset can appear in several ads; ad counts are not asset counts, and ad metrics must not be assigned to every included asset.

## C2 — Establish a relevant baseline
Compare actual creative metrics with the customer's own goal or comparable baseline. CTR can support a click-performance observation, but cannot establish downstream quality or fatigue. Unknown asset content remains unknown. Do not transfer regional or industry thresholds into the account.

## C3 — Ground requested concepts
Use customer-approved product facts, rights and observed asset features to propose hooks, messages, captions and calls to action. Keep brand constraints and prohibited claims. Drafts are proposals; a material ID alone does not reveal a scene or spoken claim.
For requested production planning, separate format, message and audience hypotheses. Include relevant captions/text overlays and visual/brand consistency, and identify the creator, reviewer and approver before use. These are planning needs, not prerequisites for a performance-only report. Quantity-and-quality review also applies to known image/carousel assets; this does not establish current format eligibility or give access to their content.

## C4 — Keep the test manageable
Prioritize a small test within the customer's budget, retain or refine promising observed messages/formats, and review against the agreed metric and guardrail. A one-variable test is an analysis option, not a universal platform rule. No universal asset minimum, benchmark or uplift applies. Outside APAC, these regional recommendations are unverified; provide factual evidence review and label strategy applicability pending.
The same regional restriction applies when the market is unknown. A two- or three-variant starting plan is optional; choose a feasible size without fragmenting the customer's budget. Review cadence and replacement depend on observed performance, mature evidence and the customer's decision, not asset age alone. No lower CPA, incremental lift or benefit from more spend is guaranteed.
