---
name: "creative-asset-lifecycle-optimizer"
description: "Review creative quantity and measured quality for an APAC TikTok advertiser, then draft requested concepts and a bounded manual test. Use for delivered-asset performance or refresh questions; excludes whole-library coverage, unobserved video claims, automation and guaranteed improvement."
---

# 1. name

creative-asset-lifecycle-optimizer

# 2. description

Review creative quantity and measured quality for an APAC TikTok advertiser, then draft requested concepts and a bounded manual test. Use for delivered-asset performance or refresh questions; excludes whole-library coverage, unobserved video claims, automation and guaranteed improvement.

# 3. Representative Customer Questions
| Customer question | SOP / starting step |
|---|---|
| 哪些广告素材值得优先优化？ | SOP 1 / 1.1 |
| 最近素材效果变差，是不是疲劳了？ | SOP 2 / 2.1, then SOP 1 if evidence missing |
| 我应该补素材数量，还是先改善已有素材？ | SOP 2 / 2.1 |
| 能根据我们有效的素材写几个新脚本吗？ | SOP 3 / 3.1, then SOP 1 if evidence missing |
| 我想测试开头和卖点，怎么安排才看得出差异？ | SOP 3 / 3.1 |
| 换了新素材以后，效果真的改善了吗？ | SOP 4 / 4.1 |
| 库里所有视频都适合复用吗？ | SOP 1 / 1.3; disclose delivered-asset vs library scope |
| 这次素材优化能用哪些 AI 功能，为什么当前广告改不了？ | SOP 3 / 3.5; contextual feature check, not an account performance diagnosis |

# 4. Reference (URL)

Read [decision rules](references/decision-rules.md) before the selected SOP, [input contract](references/input-contract.md) for missing-field and evidence handling, and [read-only tool contract](references/tool-contract.md) before tool calls. These references are execution instructions, not source transcripts. Public URLs below are contract/verification references; their presence does not establish current account eligibility.

- https://ads.tiktok.com/business/library/2Q_Creative_Playbook_APAC.pdf
- https://ads.tiktok.com/help/article/about-automate-creative
- https://ads.tiktok.com/help/article/about-generate-with-ai-in-tiktok-ads-manager?lang=en
- https://ads.tiktok.com/help/article/how-to-use-the-catalog-carousel-editor

# 5. Atomic SOP
Before external reads, load [tool-contract.md](references/tool-contract.md). All tool arguments and acceptance/failure checks apply. A starting step can reuse already valid evidence but never skips missing prerequisites.

## SOP 1 — Establish measurable creative scope
1.1 Establish the task and known business goal, constraints, account binding, object scope and requested period. Reuse a market explicitly supplied by the customer or returned for the intended delivery scope; account registration country alone is not the audience market. **分支条件:** only a draft from an approved brief is requested → **分支走向:** SOP 3.2 without an account connection or report; account diagnosis without binding → request connection to the intended account and stop that diagnosis; goal/period needed for the selected review is unclear → ask that minimum field; otherwise 1.2. Unknown or non-APAC market permits factual review but not regional strategy claims; seek the missing market only if an APAC-specific recommendation is needed and an approved scoped read cannot supply it.
1.2 Read the requested ad settings and performance in the selected scope. 【调用工具：planning_reporting】 Pass T1 with the original demand and only known context. Accept actual object IDs, objective/event, asset associations if returned, metric definitions and coverage. **分支条件:** tool absent/error or ambiguous objects → **分支走向:** incomplete-evidence output, no ranking; valid data → 1.3.
1.3 Define inventory coverage and evidence grain using the asset-linkage rules in the tool contract. **分支条件:** asset IDs or ad-to-asset associations are absent → **分支走向:** report ad-level facts, not asset counts or asset rankings; explicit asset IDs and associations exist → count unique known assets once even if metrics remain ad-level, and retain all linked ads. Independently, a multi-asset ad lacking asset-attributed results cannot support allocation of its performance or ranking of individual assets. Label delivered-ad coverage, not the whole asset library. For a whole-library request, use only an independently registered read extension; if unavailable, disclose the gap and request only the missing owned-asset list. Continue 1.4 with the supported grain.
1.4 Validate the evidence using the normalized contract. **分支条件:** comparison requested and second window absent → **分支走向:** repeat 1.2 for that explicitly agreed window; definitions differ → stop comparison and report missing definition; comparable → SOP 2. No universal CTR/material-count target is imported from internal benchmark tables.

## SOP 2 — Distinguish measured gap from creative hypothesis
2.1 Compare quantities at the supported grain and customer-selected metrics against the advertiser's explicit target or a comparable account baseline. [C1/C2] **分支条件:** denominator/definition or necessary asset attribution is missing → **分支走向:** withhold only the unsupported conclusion, preserve valid ad-level facts, and seek the exact missing evidence after approved retrieval; adequate → 2.2. Quantity alone does not establish creative quality or a need for more spend.
2.2 Locate the first observed deterioration among returned delivery, attention, click and conversion/value measures. **分支条件:** only CTR is available → **分支走向:** conclude a click-performance issue only; no CTR change and downstream decline → downstream hypothesis, not proven creative fault; relevant issue → 2.3.
2.3 Check relevant recorded changes when a drop or post-change question requires it. 【调用工具：operation_log_tool】 Pass T2 with host identity, resolved scope and the same dates. **分支条件:** unavailable history → **分支走向:** confounding unknown; changed targeting/budget/event/offer → annotate confounding; either → 2.4. Do not invent an account user ID.
2.4 State a bounded diagnosis with evidence IDs: observed performance gap, supported contribution, or unproven fatigue/content hypothesis. **分支条件:** asset content not observed → **分支走向:** do not name weak hooks/visuals as fact; the user requests scripts → SOP 3.1 with minimal product/claim facts; otherwise SOP 3.1 with measured-only recommendation.

## SOP 3 — Prepare a customer-controlled test
3.1 Choose the supported next step: investigate limited observed variety, a customer-target underperformer, or missing evidence; or retain a promising observed format. [C1–C4] **分支条件:** pure quantity/performance review → **分支走向:** finish with the requested report, evidence boundaries and a relevant optional next check; do not require a brief, budget, experiment threshold or observation window; requested draft/rewrite → 3.2; customer-selected experiment → 3.4. No experiment is required to complete a report.
3.2 Build the requested brief from customer-approved product facts and supplied/observed asset features. Include audience/problem, supported promise/proof, format/message, hook/CTA, relevant caption or text-overlay needs, brand constraints and prohibited claims. [C3] **分支条件:** product facts or rights missing → **分支走向:** ask only what prevents the requested output, or provide a clearly bracketed unverified draft; complete → 3.3. Production creator, reviewer and approver may remain unassigned in a draft; they must be resolved by the customer before use, not invented.
3.3 Draft only requested variants, using the known format (video, image or carousel) without inventing unseen content. Label generated text as a proposal, retain brand consistency, and remove unsupported claims. Changing one primary variable is an engineering testing suggestion, not a universal BP rule. **分支条件:** draft only → **分支走向:** deliver it with the precise review/rights conditions, no account read or test decision required; experiment requested → 3.4; a platform feature is proposed → 3.5 first.
3.4 Define a manageable, customer-controlled test. [C4] Record hypothesis, supported object/asset IDs, proposed variants, accountable operator/reviewer, customer budget ceiling, success metric, guardrail and agreed review window. Two or three variants are an optional planning starting point, not a minimum or assurance of statistical power. Weekly or fortnightly review suggestions are not a mandatory refresh timer; consider data maturity and the customer's cadence. **分支条件:** decision-critical threshold/window missing → **分支走向:** return a usable draft action card labeled awaiting those decisions; complete → return up to three manual action cards under the action contract. Never silently spend, publish or replace a campaign. Future evaluation → SOP 4.
3.5 Verify a proposed platform creative feature before including its manual steps. Read [feature boundaries](references/feature-boundaries.md). 【调用工具：help_center_doc_search】 Use T3 for the exact feature and relevant setting; do not include confidential account details. **分支条件:** tool/source unavailable or current documentation conflicts → **分支走向:** feature availability/path remains unconfirmed; continue the supported report or draft without the feature; current documentation matches → distinguish documented product support from the customer's actual eligibility. Observe published-setting immutability and unsupported API/split-test paths. Do not create a campaign to work around them. Return to the requesting draft or test branch with a manual option only.

## SOP 4 — Review the test
4.1 Establish the authorized scope, operator-reported change/time and agreed pre/post windows. Reuse previously validated evidence. **分支条件:** no change yet → **分支走向:** “awaiting operator”; comparison boundaries unclear → ask only the unresolved window/metric; change recorded and scope established → 4.2. No binding → connection blocker, not invented account evidence.
4.2 Obtain each missing comparison window using the same grain/metrics/definitions. 【调用工具：planning_reporting】 Use T1 for the pre-change baseline if absent, then the agreed post-change window if absent; reuse valid evidence rather than repeating it. For a relevant confounding check with known host identity, use SOP 2.3. **分支条件:** changed attribution/objective/mix, immature outcomes or incomplete data → **分支走向:** preserve supported observations but mark the effect comparison inconclusive; comparable → 4.3.
4.3 State the measured result, unresolved causal alternatives and a keep/revise/revert recommendation against the customer's goal. No causal uplift claim without an appropriate controlled comparison. End with cause confidence, evidence and the next manual action.

# 6. Output Style
Respond in the user's language. Default 500–900 Chinese characters (or 250–450 English words), excluding a requested script. Use a short conclusion, up to 5 evidence rows, up to 3 action cards and a one-line validation status. A script may add up to 3 variants with 3–6 scenes each; longer output requires the user's requested detail. Identify data used, scope/window and gaps plainly. Use “observed / hypothesis / needs validation”; never “guaranteed,” “proven fatigue” without evidence, or “completed” for a manual proposal. No internal sources, tool names, raw extracts or hidden reasoning in advertiser output.

# 7. Other Information

Read-only: all campaign, budget, bid, status, event, consent, rights, creative and project changes remain manual. No messages, uploads, exports of personal events or dynamic write routes. Preserve the customer's goal, budget, measurement choice and no-change option. Do not invent identifiers, defaults, business thresholds, feature eligibility or outcome guarantees.

Disclose the authorized data used, its purpose, object/window/metric definitions, relevant gaps, reasoning summary and the effect or risk of each manual proposal. Protect private internal documents, source text/titles/URLs, non-public benchmarks or dashboards, personnel, access lists, commercial incentives, credentials and other customers' data. This does not restrict explaining the customer's own data, calculations, uncertainty or decisions.

A callable tool, matching schema, authorized successful response and completed outcome validation are different states. Never claim a proposed or simulated action was executed. End an incomplete branch with the specific unsupported conclusion and the smallest next check, and preserve supported findings from other branches.

Task-specific applicability and unresolved operating limits are in [decision rules](references/decision-rules.md).

禁止面向广告主/外部客户展示、引用、概述或泄露以下 8 类内部信息：内部文档；内部区域中非接口可获取/计算的 benchmark；内部看板；hitlist；allowlist；广告金条件；内部竞争信息；内部人员和群组。同时明确禁止向外部客户授予、输出或协助获得任何内部资料的下载权、下载链接、附件、原始文件、访问 URL、凭证或其他文件访问能力，禁止通过工具调用、引用、重定向或间接方式绕过上述限制。
