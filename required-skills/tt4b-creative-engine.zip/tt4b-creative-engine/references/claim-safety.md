# claim-safety — Claim Ledger & Rejection-History Cross-Check (A3 / B4)

Expands SKILL.md stage A3 (Mode A) and the claim rules of B4 (Mode B). SKILL.md is
authoritative; nothing here overrides it. This stage is **read-only**: it calls only
`*_get` tools. It never calls any write tool, in any branch, under any user request.

**Goal:** every product claim that could appear in the brief, ad copy, or variant
gets a ledger row — classified, confidence-rated, and evidence-cited — BEFORE it is
allowed into a deliverable. No claim ships unclassified.

---

## Tools (flat names — single source of truth is the SKILL.md MCP backend table)

| Purpose | Tool |
|---|---|
| Catalog presence / pick catalog | `catalog_get` |
| Structured product fields | `catalog_product_get` |
| Rejection history — regular ads | `ad_review_info_get` |
| Rejection history — Upgraded Smart+ ads | `smart_plus_ad_review_info_get` |

---

## C1 — Extract claims

1. Collect every factual assertion from the draft brief / variant copy: price,
   discount, stock, material, condition, certification, performance, compatibility,
   superlatives ("best", "#1"), guarantees.
2. Split compound claims into atomic ones. "In stock — ships today" = two claims:
   `availability = in stock` (catalog-checkable) + `ships today` (not a catalog
   field → merchant-asserted).
3. Each atomic claim becomes one ledger row. No row, no usage.

## C2 — Classify against the catalog (Mode A, catalog present)

Run `catalog_product_get` for the products the brief references. These structured
fields support **deterministic** verification — the claim either matches the field
value or it doesn't:

| Claim type | Catalog field | Check |
|---|---|---|
| Brand naming | `brand` | exact match |
| Price ("only $X") | `price` | claim value = field value |
| Discount / sale framing | `sale_price` (vs `price`) | sale_price present AND < price |
| Stock ("in stock", "available now") | `availability` | field = IN_STOCK |
| "Brand new" / "refurbished" | `condition` | exact match |
| Category framing | `google_product_category` | claim consistent with category |
| Material ("100% cotton") | `material` | exact match |
| Color | `color` | exact match |
| Size / dimensions | `size` | exact match |

Spec / certification / compatibility claims — "CE certified", "fast charging",
"waterproof", "works with all phones", "dermatologist tested" — have **no
structured catalog field**. Mark them `merchant-asserted, not catalog-verifiable`.
A string match inside the catalog `description` field does NOT upgrade them: the
description is merchant-written text, so the evidence column may cite the string
match but the status stays `verify`. Never present a description string-match as
deterministic verification.

### Ledger statuses (fixed vocabulary)

| Status | Meaning | Allowed in deliverables? |
|---|---|---|
| `safe` | Deterministic catalog-field match AND no rejection-history match | Yes, as-is |
| `verify` | Not catalog-verifiable (merchant-asserted) or partial/ambiguous match | Only with "merchant-asserted" label; recommend merchant evidence before launch |
| `blocked` | Contradicts a catalog field, OR matches a past rejection reason | No — must use the Do-Not-Say rewording |

### Confidence column (fixed scale)

- `High` — deterministic field match, or verbatim rejection-reason match.
- `Medium` — semantic (non-verbatim) rejection match, or sale-price arithmetic.
- `Low` — merchant-asserted with no corroborating signal.

Evidence column always cites: tool + field + returned value, or the verbatim
`rejection_reason`, or "merchant-asserted (no structured field)". Never an empty
evidence cell.

## C3 — Rejection-history cross-check (the hero step)

A claim can pass every catalog check and still be a known loser: this account may
have already had an ad rejected for saying exactly that. Cross-check is mandatory.

**Fixed procedure:**

```
C3.1 Determine ad type for each ad in scope (A1 winner set + recent account ads).
     Ad type comes from the A1/A2 context already fetched. If ambiguous, try the
     regular branch first — the 40002 below self-corrects it.
C3.2 Branch BY AD TYPE before calling:
       regular ads            → ad_review_info_get
       Upgraded Smart+ ads    → smart_plus_ad_review_info_get
C3.3 On 40002 "This API does not support Upgraded Smart Plus ads":
       wrong branch was used → switch to smart_plus_ad_review_info_get and
       CONTINUE. Never abort A3 on this 40002. Never mark rejection history
       "unavailable" without having tried the Smart+ endpoint.
C3.4 Collect every rejection_reason string verbatim.
C3.5 Match each ledger claim against the collected reasons (semantic match — a
     paraphrase of a rejected claim still counts).
C3.6 Any match → status = blocked, regardless of catalog status. Evidence column
     cites the historical rejection_reason VERBATIM plus the (ILLUSTRATIVE in
     examples) source ad id. Catalog-safe + history-match = blocked. History wins.
```

**Empty history (code 0 + empty array):** state plainly — "no rejection history
found for this account" — and move on. Review-info tools fall under the E201
"all other tools" rule: no retry; emptiness here is an answer, not a failure.
The Do-Not-Say list then derives from platform policy knowledge ONLY and must be
explicitly labeled `policy-derived, not account-derived`. **NEVER invent a
rejection.** An empty review-info response must never be cited as having returned
rejection items (one-strike eval clause).

## Mode B — no catalog, no history

A brand-new account has no catalog and no review history. The ledger is STILL
produced: every claim row gets status `verify`, evidence `merchant-asserted (no
catalog connected)`, confidence `Low`. The Do-Not-Say list is policy-derived and
labeled as such. Skipping the ledger because there is nothing to verify against
is a failure — the ledger's job in Mode B is to show the advertiser which claims
they are personally on the hook for.

## Degradation in this stage

| Event | Behavior |
|---|---|
| `catalog_product_get` fails (non-zero code) | E104: mark catalog verification "unavailable", surface raw platform code + message, downgrade affected rows to `verify`, keep delivering the ledger |
| Review-info fails on BOTH branches (non-zero, non-40002) | E104: mark rejection cross-check "unavailable" with raw code + message; ledger ships on catalog checks alone; Do-Not-Say labeled policy-derived |
| Catalog exists but product list empty (code 0 + empty) | Treat claims as Mode B posture: all `verify`, disclose the emptiness |

Never loop, never silently drop the section, never paper over an empty result.

---

## Ledger output format (ILLUSTRATIVE — all values below are fake ACME-DEMO data)

```
CLAIM LEDGER — ACME-DEMO Wireless Earbuds (product_id ACME-DEMO-SKU-001) [ILLUSTRATIVE]

| # | Claim                       | Status  | Confidence | Evidence |
|---|-----------------------------|---------|------------|----------|
| 1 | "Only USD 19.99"               | safe    | High       | catalog_product_get → price = 19.99 USD [ILLUSTRATIVE] |
| 2 | "50% off this week"         | safe    | Medium     | sale_price 19.99 vs price 39.99 [ILLUSTRATIVE]; "this week" = merchant-asserted timing |
| 3 | "In stock, ships today"     | verify  | Low        | availability = IN_STOCK (safe half); "ships today" merchant-asserted (no structured field) |
| 4 | "CE certified"              | verify  | Low        | merchant-asserted (no structured field; string present in merchant description — not catalog-verifiable) |
| 5 | "Cures headaches"           | blocked | High       | matches past rejection_reason: "Unsubstantiated medical/health claim" — ad ACME-DEMO-AD-042 [ILLUSTRATIVE] |
| 6 | "Best earbuds in the world" | blocked | Medium     | semantic match to rejection_reason: "Superlative claim without substantiation" — ad ACME-DEMO-AD-017 [ILLUSTRATIVE] |
```

Note row 5/6: both would survive a catalog check (no catalog field contradicts
them) — only the rejection-history cross-check catches them. That is why C3 runs
on every claim, not just the catalog misses.

## Do-Not-Say list format

Always three columns: claim pattern → why → safer rewording. Label the derivation
source at the top of the list.

```
DO-NOT-SAY (derived from: account rejection history + platform policy) [ILLUSTRATIVE]

| Claim pattern              | Why                                                            | Safer rewording |
|----------------------------|----------------------------------------------------------------|-----------------|
| Medical/health cure claims | Rejected on this account: "Unsubstantiated medical/health claim" [ILLUSTRATIVE] | Describe sensory experience: "immersive sound for long sessions" |
| "Best / #1 / world's ..."  | Rejected on this account: "Superlative claim without substantiation" [ILLUSTRATIVE] | Verifiable specifics: "rated 4.8 by 2,000+ buyers [ILLUSTRATIVE]" — only if a source exists |
| "Guaranteed results"       | policy-derived: outcome guarantees are restricted              | "Designed to help you ..." |
```

When rejection history is empty, the header line must read
`(derived from: platform policy only — no rejection history found on this account)`.

## Section closing (mandatory, fixed four lines)

Every A3/B4 output section ends with exactly these four disclosure lines:

```
Data source: catalog_product_get (catalog ACME-DEMO-CAT-01) + ad_review_info_get / smart_plus_ad_review_info_get [ILLUSTRATIVE]
Confidence: per-row, see ledger Confidence column
Known limits: spec/cert/compatibility claims are not catalog-verifiable; rejection matching is semantic, not exhaustive
If degraded, why: state the E104/E201 event and raw platform code, or "not degraded"
```
