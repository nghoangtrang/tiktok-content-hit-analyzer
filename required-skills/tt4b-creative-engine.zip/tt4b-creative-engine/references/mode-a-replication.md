# Mode A — Winner Replication (operational reference)

Expands SKILL.md §Mode A. SKILL.md is authoritative; on any conflict, SKILL.md wins.
Read-only throughout: Mode A calls report/info tools only — never any
`campaign_create`-class write tool. All example data below is ILLUSTRATIVE
(`ACME-DEMO` tokens, fake numbers) — never real account data.

**Stage flow:**
```
A1 rank winners (real report metrics)
→ A2 infer winning structure (3 signals, confidence-tagged hypotheses)
→ A3 claim ledger + rejection cross-check   → details: claim-safety.md
→ A4 variants + A/B test plan (one arm = one A2 hypothesis)
```
Each stage ends with the four fixed disclosure lines (template at bottom).

---

## A1 — Winner ranking

### Call parameters (sync default)

| Param | Value |
|---|---|
| tool | `report_integrated_get` |
| `advertiser_id` | from S0 |
| `report_type` | `BASIC` |
| `data_level` | `AUCTION_AD` |
| `dimensions` | `["ad_id"]` |
| `metrics` | `spend, impressions, clicks, ctr, conversion_rate, conversion, cost_per_conversion, purchase_roas, video_watched_2s, video_watched_6s, video_views_p25, video_views_p50, video_views_p75, video_views_p100` |

ROAS/CPA fields (`purchase_roas`, `cost_per_conversion`) are RYZE-gated on some
accounts — request them, expect possible null (degradation rule below).

> ⚠️ Metric-name trap (live-verified): `cvr` is NOT a valid metric for AD-level
> BASIC reports — the call fails with `40002 Invalid metric fields: ['cvr']`.
> Use `conversion_rate`. On a 40002 naming this field, fix the name and retry
> once; do not drop the metric silently.

### Window policy — run two passes

| Pass | Window | Purpose |
|---|---|---|
| 1 | LIFETIME roll-up (lifetime flag per tool schema; no per-day split) | stable all-time winners |
| 2 | last 30 days | current winners / fatigue check |

Rank on pass 1. If the lifetime #1 has near-zero impressions in pass 2, flag it
"likely fatigued" and surface the top pass-2 ad alongside — disclose both, pick
neither silently. Pass 1 returning 0 rows = Mode A prerequisite missing →
`E103_NO_AD_DATA` → declare switch to Mode B (not a failure).

### Sync vs async routing rule

- **Sync `report_integrated_get` (default):** both passes above. LIFETIME at AD
  level is one roll-up row per ad — sync handles it.
- **Async report task trio** — route here ONLY when a per-day AD-level breakdown
  over a range > 30 days is genuinely required, or the sync call returns
  truncated/row-capped: submit the task (`report_task_create`, same params as the
  sync call plus the date split) → poll `report_task_check` every ~5s
  (`SUCCESS` → download; `FAILED` → treat as `E104_PARTIAL_API_FAIL`: surface raw
  code/message, fall back to the sync 30-day window, continue) →
  `report_task_download`.
- Naming note: `report_task_create` is the reporting-export entry point sanctioned
  by SKILL.md's tool map ("async report task trio"). It materializes a report
  file — it never creates, modifies, or spends against any ad object. Every
  campaign-object write tool remains banned one-strike.

### Ranking keys

1. `purchase_roas` desc → 2. `cost_per_conversion` asc → 3. `conversion_rate` desc →
4. `ctr` desc → tiebreak: hook-rate. `spend` is exposure context, never a
ranking key on its own.

**RYZE paywall degradation:** ROAS/CPA null or gated → rank by CTR / conversion_rate /
hook-rate instead, and state the substitution explicitly in the section body AND
in the `If degraded, why` line (e.g. "ROAS/CPA unavailable on this account
(subscription-gated); ranking degraded to CTR/CVR/hook-rate"). Pretending to
rank by ROAS = fabrication.

### Derived metrics (compute, label `derived`)

| Metric | Formula |
|---|---|
| hook-rate | `video_watched_2s / impressions` |
| completion rate | `video_views_p100 / impressions` |

Derived values must show the formula on first use and carry the `derived` label —
they are arithmetic on tool returns, not tool returns themselves.

### Low-volume disclosure (mandatory)

- Top-ranked winner < 1,000 lifetime impressions → the ranking output MUST carry
  an explicit low-data confidence warning before anything else in the section.
- CTR > 100% (or any impossible metric) → flag as test/diagnostic noise — never
  present as a win. Common in test environments.
- A2–A4 may proceed, with every downstream confidence capped at `medium`.

### ILLUSTRATIVE output shape

```
[A1 Winner Ranking · LIFETIME · ILLUSTRATIVE TEMPLATE — not real account data]
⚠️ LOW-DATA WARNING: top ad has 37 lifetime impressions (< 1,000) — ranking
   confidence is low; metrics below are directional at best.

  #  Ad             Imps  Clicks  CTR      CVR    Hook-rate (derived)
  1  ACME-DEMO-AD-01  37      57  154.0%⚠  4.2%   61.0%
  2  ACME-DEMO-AD-02  29       1    3.4%   0.0%   48.0%

⚠ CTR 154.0% is impossible — flagged as test/diagnostic noise, excluded from
  "winner" framing.
```

---

## A2 — Structure inference (INFER, not decode)

The API exposes no transcript, captions, or on-screen text. A2 INFERS structure
from three signals; it never claims to have decoded the video.

| # | Signal | Source | Notes |
|---|---|---|---|
| 1 | Retention drop-off points | A1 funnel (`p25→p50→p75→p100` vs `impressions`); per-second curve via `report_video_performance_get` (`advertiser_id`, `report_type=VIDEO`, `material_ids=[...]`) when available | per-second curve is the strongest signal — but ONLY when its `material_id` is confirmed as the winner's own video; unconfirmed attribution → demote to supporting signal, cap dependent hypotheses at `medium`, state the gap in Known limits |
| 2 | Ad copy | ad text from the A1 ad rows; material metadata via `file_video_ad_info_get` (`video_ids`) | copy reveals claim, offer, CTA framing |
| 3 | Cover image | ONE multimodal read of the poster/cover URL from `file_video_ad_info_get` | exactly one read; no frame-by-frame decoding |

**Scope:** run A2 on the #1 winner. Include #2/#3 only if the user asks or A1
ranks are indistinguishable under the low-volume rule.

**Cover degradation:** cover URL unreachable (CDN blocked, expired, fetch fails)
→ proceed on two signals (retention + copy), add the fixed disclosure
"cover unreachable", and drop or downgrade to `low` any hypothesis that depended
on the cover alone. Do not retry the fetch more than once.

**Signal failure:** `report_video_performance_get` errors → `E104_PARTIAL_API_FAIL`
(mark per-second curve "unavailable", surface raw code/message, continue on the
p25–p100 funnel).

### Confidence rules (deterministic)

| Confidence | Condition |
|---|---|
| high | ≥ 2 signals independently support the hypothesis |
| medium | exactly 1 strong signal (e.g. a sharp per-second drop) |
| low | 1 weak signal, or signals conflict, or A1 low-volume cap applies |

### Output format — hypotheses table

```
[A2 Structure Hypotheses · ACME-DEMO-AD-01 · ILLUSTRATIVE TEMPLATE]

  #  Hypothesis (structure element)       Signal evidence            Confidence  Testable variable
  H1 Hook lands in first 2s (problem-     hook-rate 61% (derived) +  high        opening hook framing
     first opening)                       copy opens with pain point
  H2 Mid-video offer reveal causes        per-second drop at ~9s     medium      offer reveal timing
     drop-off                             (ILLUSTRATIVE)
  H3 Cover promise mismatches first       cover read only            low         cover-to-opening match
     frame
```

**Fixed disclosure (verbatim, every A2 output):** "the API exposes no
transcript/captions/on-screen text — inference uses retention + copy + cover".

---

## A3 — Claim verification (pointer)

Full procedure: [claim-safety.md](claim-safety.md). Carry-over rules that bind
here: determine ad type BEFORE requesting review info — regular ads →
`ad_review_info_get`; Upgraded Smart+ ads → `smart_plus_ad_review_info_get`. A
`40002 "This API does not support Upgraded Smart Plus ads"` means wrong branch:
switch and continue — never abort A3 or mark rejection history "unavailable" on
that 40002 without trying the Smart+ endpoint. Empty rejection history is
reported as "no rejection history found" — never invented.

---

## A4 — Variants + A/B test plan

### Variant rules

- Produce **3–5 variants** plus the unmodified winner structure as control.
- Each variant isolates **exactly ONE testable variable**, wired to **exactly ONE
  A2 hypothesis** (use the `Testable variable` column). No multi-change arms.
- Prioritize hypotheses by confidence: every `high` gets an arm before any
  `medium`; `low` hypotheses get an arm only if slots remain.
- Every variant passes the A3 claim ledger before it ships in the brief: no
  `blocked` claims, `verify` claims flagged inline.

### Expected impact — MDE discipline (no assumed numbers)

Expected impact is framed as the **minimum detectable effect (MDE)** derived
from the winner's own real A1 baseline and the planned sample size — every
number is derived arithmetic, none is assumed. Form:
"baseline p (real, from A1) → at n per arm, MDE ≈ 2.8 × √(2·p·(1−p)/n)
(derived; α=0.05, power 0.8) → success criterion = baseline + MDE".
Also state the inverse when useful: "to detect a +Δ lift would require
n ≈ 15.7 × p·(1−p)/Δ² per arm (derived)". Never output an unlabeled industry
benchmark or an invented uplift percentage; if the user supplies a target lift,
label it `user provided` and derive the required n from it.

### Test plan fields (per arm, all mandatory)

| Field | Rule |
|---|---|
| Arm / hypothesis | variant id + the single A2 hypothesis it validates |
| Isolated variable | the one change; everything else held to winner structure |
| Baseline | winner's real A1 metric for the target measure |
| Expected impact | MDE per the discipline above (derived from real baseline + planned n; no assumed uplift) |
| Sample floor | read no metric before its denominator floor: CTR → ≥ 1,000 impressions/arm; CVR → ≥ 100 clicks/arm |
| Duration | 7–14 days (≥ 7 to clear day-of-week effects) |
| Success criteria | pre-registered: metric + direction + minimum delta vs control |

### ILLUSTRATIVE arm

```
[A4 Test Plan · arm V1 · ILLUSTRATIVE TEMPLATE — not real account data]
Validates: H1 (opening hook framing, confidence high)
Isolated variable: problem-first hook → social-proof hook; all else = winner structure
Baseline: winner CTR 1.8% (ILLUSTRATIVE)
Expected impact: at n=2,500 impressions/arm, MDE ≈ 2.8 × √(2·0.018·0.982/2500)
  ≈ +1.05pp (derived; α=0.05, power 0.8) → detectable lift threshold ≈ 2.85% CTR
Sample floor: ≥ 2,500 impressions/arm (sized so the MDE is meaningfully small)
Duration: 14 days
Success (pre-registered): CTR ≥ 2.85% AND ≥ control arm; else H1 framing variant rejected
```

Execution of the test belongs to the launch family — close with the route-out:
"To run this test, hand the arms to `tt4b-launch-traffic-campaign` (or the
matching launch skill)." Never create the split test yourself.

---

## Per-section disclosure block (mandatory, all of A1–A4)

```
Data source:       <tools called + windows | "agent reasoning only (A4 design)">
Confidence:        <high / medium / low + one-line reason>
Known limits:      <fixed limits, e.g. no transcript/captions exposed by the API>
If degraded, why:  <substitution or loss + cause | "not degraded">
```

Every concrete number above either traces to a tool return, carries `derived` /
`projection` with its formula, or is `ILLUSTRATIVE`. No fourth category exists.
