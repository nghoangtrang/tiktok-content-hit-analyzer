# Mode B — Cold-Start Engine (zero delivery history)

Operational detail for SKILL.md's Mode B. SKILL.md hard invariants apply verbatim:
read-only everywhere, no fabrication, honest emptiness. This file never overrides
SKILL.md — if anything here seems to conflict, SKILL.md wins.

Entry condition (declared in S0): campaign=0, report rows=0, no catalog. The
account has nothing to mine — every number in Mode B comes from **live market
tools**, not account history.

All tool names are flat (`tt-ads-mcp-flat`). All example data below uses
`ACME-DEMO` tokens and is **ILLUSTRATIVE** — never echo it as real output.

---

## Inputs (collect before B1)

| Input | Required | Used by |
|---|---|---|
| Product name | yes | B1 seed terms, B4 hooks |
| Selling points (bullet list) | yes | B1 seed terms, B4 hooks, claim tagging |
| Landing-page text (paste or summary) | no — degrade gracefully | B4 copy, claim tagging |
| Target market (country/region) | yes | every B1–B3 call (region params) |

If product name or target market is missing, ask once, then proceed with what you
have and disclose the gap. Do NOT stall on optional inputs.

**Claim rule (mandatory):** there is no catalog and no review history on this
account, so NOTHING the user asserts can be verified. Every product claim that
flows into B4 copy or the starter packet is tagged `merchant-asserted`. Pair the
brief with the policy Do-Not-Say list (see [claim-safety.md](claim-safety.md)).
Never present a merchant assertion as a verified fact.

---

## B1 — Market demand (keyword evidence)

Tools: `tool_search_keyword_idea_get`, `tool_search_keyword_recommend`.

1. Build 3–6 seed terms from product name + selling points. Single words or short
   2-word phrases; one concept per seed.
2. Call `tool_search_keyword_idea_get` per seed (target market region). Extract
   per keyword: monthly search-volume range, competition level (LOW/MEDIUM/HIGH),
   CPC range, 3-month trend, YoY trend.
3. Call `tool_search_keyword_recommend` on the 2–3 strongest seeds to widen the
   matrix with adjacent demand.
4. Output a keyword matrix table sorted by search volume. Flag rising terms
   (positive 3-month trend) — they feed B4 hooks.

**Bid anchor rule:** the B1 CPC range is the ONLY honest bid anchor on a cold
account. `tool_bid_recommend` is disabled (constant USD 1 — see Disabled tools).
Every bid or budget projection downstream (B5 packet) must cite the B1 CPC range
as its source, labeled `projection`.

ILLUSTRATIVE example row (fake numbers — never reuse):

| Keyword | Vol/mo | Competition | CPC range | 3-mo trend | YoY |
|---|---|---|---|---|---|
| acme-demo gummies | 10K–100K (ILLUSTRATIVE) | MEDIUM | USD 0.40–USD 0.90 (ILLUSTRATIVE) | +12% (ILLUSTRATIVE) | +30% (ILLUSTRATIVE) |

Close the section with the four disclosure lines (template at bottom).

---

## B2 — Audience profile + reach

Tools: `audience_insight_info_get`, `ad_audience_size_estimate`.

**Hard constraint:** `audience_insight_info_get` accepts ONE dimension per call.
Never batch dimensions. Fixed serial order:

1. Call 1 — dimension `age`: age distribution for the target market.
2. Call 2 — dimension `top_interests`: dominant interest categories.
3. `ad_audience_size_estimate` with the draft targeting (market + age bands from
   call 1 + top interests from call 2) → reachable-user range.

The audience-size range is the reach ceiling for the B5 cost/reach projection.
Report it as a range exactly as returned; never collapse it to a single number.

If an insight call returns empty: E201 policy (one retry, drop filters), then
disclose and continue — an empty insight does NOT block B3/B4.

Close with the four disclosure lines.

---

## B3 — Targeting package (interest + hashtag keyword IDs)

Tools: `tool_interest_keyword_recommend_search`, `tool_hashtag_recommend_search`.

These two tools have live-verified parameter traps. Apply the defense table on
the FIRST call, not as a retry:

| Trap (live-verified) | Symptom | Defense (mandatory) |
|---|---|---|
| Multi-word seed with AND semantics | `code 0` + empty array — silent, no error | Split every multi-word seed into single words BEFORE calling |
| Default AND across words | Same silent empty | Force OR semantics explicitly |
| Single-word fuzzy matching | Returns irrelevant strings (garbage hits) | LLM post-filter: drop every hit not plausibly related to the product/market; disclose that the filter was applied |

Procedure:

1. Derive single-word seeds from the B1 keyword matrix winners.
2. `tool_interest_keyword_recommend_search` (single words, OR) → interest
   keyword candidates with IDs.
3. `tool_hashtag_recommend_search` (single words, OR) → hashtag candidates.
4. LLM post-filter both lists against product + market context. Keep 10–20
   relevant entries; state how many raw hits were discarded.
5. Output the package as `keyword_id` lists ready to paste into the adgroup
   draft payload (B5 consumes them verbatim).

ILLUSTRATIVE output shape:

```
interest_keyword_ids: [900001 (ILLUSTRATIVE, "acme-demo"), 900002 (ILLUSTRATIVE, "wellness")]
hashtag_ids:          [810001 (ILLUSTRATIVE, "#acmedemo")]
discarded by post-filter: 14 fuzzy hits (ILLUSTRATIVE)
```

Close with the four disclosure lines.

---

## B4 — Creative brief

Inputs: B1 matrix, B2 profile, user selling points. Tools:
`creative_cta_recommend_get`, `file_video_suggestcover_get` (conditional).

**Hook matrix (the core deliverable).** One hook per strong keyword angle.
Rank by composite score = volume tier × growth tier × inverted competition tier:

| Factor | Tiering |
|---|---|
| Search volume | high=3 / mid=2 / low=1 (from B1 ranges) |
| 3-month growth | rising=3 / flat=2 / declining=1 |
| Competition (inverted) | LOW=3 / MEDIUM=2 / HIGH=1 |

Highest product wins. Show the score columns so the ranking is auditable. Each
hook row carries: angle, target audience segment (from B2), opening line
(LLM-drafted), and which B1 keyword(s) evidence it.

**CTA:** call `creative_cta_recommend_get` for the campaign objective; present
returned CTAs as tool-sourced. If empty → E201 (no retry), degrade to
LLM-drafted CTA labeled `LLM-drafted`.

**Cover candidates:** call `file_video_suggestcover_get` ONLY if the asset
library has at least one video (check `file_video_ad_search` first). Cold
accounts usually have none — silent skipping is forbidden: disclose "no videos
in asset library, cover suggestion skipped."

**Ad copy:** drafted by the LLM from merchant-asserted selling points. Label
every line `LLM-drafted` + `merchant-asserted` where it carries a product claim.
Note in the brief: `creative_smart_text_get` (platform copy generator) unlocks
only after the first adgroup exists — list it as a post-launch upgrade, do not
call it now.

Close with the four disclosure lines, then proceed to B5: the campaign starter
packet ([campaign-starter-packet.md](campaign-starter-packet.md)) — dry-run
only, `[DRY_RUN_PREVIEW]` marker, hand-off to `tt4b-launch-traffic-campaign`.

---

## Disabled tools (verified dead or misleading on cold accounts — do NOT call)

| Tool | Why disabled | Substitute |
|---|---|---|
| `tool_bid_recommend` | Returns a constant USD 1 on cold accounts (live-verified) | B1 CPC ranges as the bid anchor |
| `report_ad_benchmark_get` | Requires own ads ≥1,000 impressions — impossible at zero history | B1 CPC + B2 audience size drive all projections |
| `tool_targeting_category_recommend_get` | Returns irrelevant categories without app context | B3 interest/hashtag keyword tools |
| `spark_ad_recommend_get` | Requires TCM authorization | Mention Spark Ads as a post-launch option only |

Calling any of these in Mode B is a contract violation even if the call would
succeed — their outputs are misleading, not merely empty.

---

## E201 empty-result policy (Mode B, per tool — max ONE retry)

`code 0` + empty array is common and is NOT an error code. Fixed strategies:

| Tool | Retry (at most once) |
|---|---|
| `tool_search_keyword_idea_get` / `tool_search_keyword_recommend` | Swap seed term (next selling-point noun) |
| `tool_interest_keyword_recommend_search` | Swap seed term (defense table already enforced on first call) |
| `tool_hashtag_recommend_search` | Split multi-word seeds + force OR (if already split: swap seed) |
| `audience_insight_info_get` | Drop filters, re-query the same dimension |
| `ad_audience_size_estimate` | No retry — mark reach ceiling unavailable, disclose |
| `creative_cta_recommend_get` | No retry — degrade to LLM-drafted CTA, labeled |
| `file_video_suggestcover_get` | No retry — skip cover section, disclose |

After the single retry still returns empty: state the emptiness, degrade the
section, continue the run. Never loop, never fabricate items, never silently
drop the section.

---

## Per-section disclosure block (mandatory, exactly four lines)

Every B1–B4 section ends with:

```
Data source:      <tools called + params that matter, or "user-provided">
Confidence:       <high / medium / low + one-clause reason>
Known limits:     <e.g. "claims merchant-asserted; no catalog to verify">
If degraded, why: <E-code + what was substituted, or "not degraded">
```
