# Worked example 02 — Mode B cold start (zero history → dry-run starter packet)

> ILLUSTRATIVE EXAMPLE — all data synthetic (ACME-DEMO tokens). Not real account data.

Demonstrates: S0 ladder (BC empty → advertiser fallback), declarative routing with no
confirmation wait, B1–B5, the E201 hashtag retry (split + force OR), merchant-asserted
claim tagging, the `[DRY_RUN_PREVIEW]` packet, and the route-out refusal on "just create it".

---

**User:** Brand-new TikTok Ads account. I sell magnetic phone chargers — snap-on, works
with recent phone models, slim. Target the US, USD 20/day. What should my first campaign be?

**Skill:** Running S0 preflight.
- `bc_get` → code 0, empty list — no Business Center. Not a stop: ladder falls through.
- `auth_advertiser_get` → 1 advertiser: `ACME-DEMO-001` ("Acme Demo Gadgets"). Continuing.
- `advertiser_info_get` (advertiser_id=ACME-DEMO-001) → `status: STATUS_ENABLE` — healthy.
- `identity_get` (identity_type=TT_USER — never unfiltered) → 1 identity: `ACME-DEMO-IDENTITY-01`.
- `campaign_get` → 0 campaigns · `report_integrated_get` (campaign level, LIFETIME) → 0 rows · `catalog_get` → no catalog.

**Entering Mode B (cold start). Basis: campaign=0, report rows=0, no catalog. Say so to
force Mode A.** Proceeding immediately.

### B1 — Market demand
- `tool_search_keyword_idea_get` (region=US; seeds: "magnetic charger", "magsafe", "wireless charger", "car mount") → 4 result sets
- `tool_search_keyword_recommend` (region=US; seeds: "magnetic charger", "magsafe") → 11 adjacent keywords

| Keyword (all ILLUSTRATIVE)  | Vol/mo   | Competition | CPC range   | 3-mo trend | YoY  |
|-----------------------------|----------|-------------|-------------|------------|------|
| magsafe charger             | 100K–1M  | HIGH        | USD 0.55–USD 0.95 | +4%        | +9%  |
| magnetic phone charger      | 10K–100K | MEDIUM      | USD 0.40–USD 0.95 | +18% ↑     | +35% |
| magnetic car mount charger  | 10K–100K | LOW         | USD 0.35–USD 0.70 | +22% ↑     | +41% |
| wireless charging stand     | 10K–100K | HIGH        | USD 0.60–USD 0.95 | −3%        | +6%  |

Rising terms (↑) feed the B4 hook matrix. Bid anchor = "magnetic phone charger" CPC range
USD 0.40–USD 0.95 (ILLUSTRATIVE). `tool_bid_recommend` is disabled (constant USD 1 on cold accounts) — not called.

    Data source:      tool_search_keyword_idea_get + tool_search_keyword_recommend, region=US
    Confidence:       medium — live market ranges, market-level not account-level
    Known limits:     volumes are ranges, not exact counts
    If degraded, why: not degraded

### B2 — Audience profile + reach (ONE dimension per call, fixed serial order)
- `audience_insight_info_get` (dimension=age, region=US) → 18–24: 31%, 25–34: 38%, 35–44: 19% (ILLUSTRATIVE)
- `audience_insight_info_get` (dimension=top_interests, region=US) → Tech & Electronics, Car Accessories, Travel (ILLUSTRATIVE)
- `ad_audience_size_estimate` (US, ages 18–44, interests above) → 21,000,000–26,000,000 reachable users (ILLUSTRATIVE; reported as a range, never collapsed)

    Data source:      audience_insight_info_get (age, then top_interests) + ad_audience_size_estimate
    Confidence:       medium — market-level insight, no account history to refine it
    Known limits:     size estimate reflects draft targeting, not a delivery forecast
    If degraded, why: not degraded

### B3 — Targeting package (interest + hashtag keyword IDs)
- Seeds from B1 winners, split to single words with OR semantics (defense table): ["magnetic", "charger", "magsafe", "mount"]
- `tool_interest_keyword_recommend_search` (single-word seeds, OR forced) → 23 raw hits
- `tool_hashtag_recommend_search` (seed "car mount") → code 0 + EMPTY array — the silent multi-word AND trap fired
- E201 retry (once): split "car mount" → ["car", "mount"] + force OR → 9 hits. (Production runs apply the split+OR defense on the FIRST call; this retry shows the documented recovery path.)
- LLM post-filter both lists against product + US market → kept 12 interest + 6 hashtag entries

```
interest_keyword_ids: [900101 ("magnetic"), 900102 ("charger"), 900103 ("magsafe"), … 12 total] (ILLUSTRATIVE)
hashtag_ids:          [810201 ("#magsafe"), 810202 ("#carmount"), … 6 total] (ILLUSTRATIVE)
discarded by post-filter: 14 fuzzy hits unrelated to phone charging (disclosed)
```

    Data source:      tool_interest_keyword_recommend_search + tool_hashtag_recommend_search (single-word seeds, OR)
    Confidence:       medium — tool-returned IDs, relevance filtered by LLM (disclosed)
    Known limits:     single-word fuzzy matching; post-filter is judgment, not data
    If degraded, why: E201 on hashtag seed "car mount" — one retry (split + force OR) recovered it

### B4 — Creative brief (hook matrix ranked by volume × growth × inverted competition)

| # | Hook angle        | B1 evidence                | Vol | Grw | Comp⁻¹ | Score | Audience (B2)        | Opening line (LLM-drafted)                  |
|---|-------------------|----------------------------|-----|-----|--------|-------|----------------------|---------------------------------------------|
| 1 | Car-mount one-hand| magnetic car mount charger | 2   | 3   | 3      | 18    | 25–34, Car Accessories| "Your car charger shouldn't need two hands."|
| 2 | Snap-on speed     | magnetic phone charger     | 2   | 3   | 2      | 12    | 18–34, Tech & Electr. | "Stop fumbling with cables. It just snaps." |
| 3 | MagSafe-style fit | magsafe charger            | 3   | 2   | 1      | 6     | 18–24, Tech & Electr. | "That satisfying magnetic click — for less."|

Product claims in copy — ALL `merchant-asserted` (no catalog, no review history to verify):
"snaps on in one motion", "works with recent phone models", "slim". Do-Not-Say
(policy-derived, not account-derived — no rejection history exists on this account): no
charging-speed superlatives ("fastest"), no battery-safety guarantees.
- `creative_cta_recommend_get` (objective=TRAFFIC) → `SHOP_NOW`, `LEARN_MORE` (tool returned)
- `file_video_ad_search` → 0 videos — no videos in asset library, cover suggestion skipped (`file_video_suggestcover_get` not called)
- `creative_smart_text_get` unlocks only after the first adgroup exists — listed as post-launch upgrade, not called.

    Data source:      B1 matrix + B2 profile + creative_cta_recommend_get; copy LLM-drafted from user selling points
    Confidence:       medium — ranking is auditable arithmetic on B1/B2; copy is unvalidated draft
    Known limits:     all product claims merchant-asserted; no catalog to verify against
    If degraded, why: cover section skipped — zero videos in asset library (disclosed, not silent)

### B5 — Campaign starter packet
- Read declared input schemas of `campaign_create` + `adgroup_create` (metadata only — these tools are NEVER called)

```
[DRY_RUN_PREVIEW] Campaign starter packet — ILLUSTRATIVE, not real account data

Advertiser: ACME-DEMO-001 · Mode B · 2026-06-15 (ILLUSTRATIVE)

| # | Field                | Value                                     | Source         | Schema-validated |
|---|----------------------|-------------------------------------------|----------------|------------------|
| C1| objective_type       | TRAFFIC (pixel-free chain)                | default        | ✓ |
| C2| campaign_name        | acme-charger-US-20260615-traffic          | derived        | ✓ |
| C3| budget_mode          | BUDGET_MODE_INFINITE                      | default        | ✓ |
| G1| campaign_id          | — (assigned by campaign_create at launch) | unavailable    | ✗ missing required: campaign_id |
| G2| promotion_type       | WEBSITE                                   | default        | ✓ |
| G3| optimization_goal    | CLICK                                     | default        | ✓ |
| G4| billing_event        | CPC                                       | default        | ✓ |
| G5| bid_price            | USD 0.68 (B1 CPC range midpoint, ILLUSTRATIVE)| derived       | ✓ |
| G6| budget (daily)       | USD 20.00                                    | user provided  | ✓ |
| G7| schedule             | SCHEDULE_FROM_NOW, 2026-06-15 00:00       | default/derived| ✓ |
| G8| location_ids         | [60000001] (US, ILLUSTRATIVE)             | derived        | ✓ |
| T1| interest_keyword_ids | [900101, 900102, 900103, …] (ILLUSTRATIVE)| tool returned  | ✓ |
| T2| hashtag keyword IDs  | [810201, 810202, …] (ILLUSTRATIVE)        | tool returned  | ✓ |
| K1| hook                 | "Your car charger shouldn't need two hands." | derived     | n/a (creative) |
| K2| CTA                  | SHOP_NOW                                  | tool returned  | n/a (creative) |
| K3| identity             | ACME-DEMO-IDENTITY-01 (ILLUSTRATIVE)      | tool returned  | n/a (creative) |

Projections (arithmetic on real inputs — not guarantees):
  Daily clicks: USD 20 ÷ USD 0.95 ≈ 21 … USD 20 ÷ USD 0.40 = 50 → 21–50 clicks/day
                (projection; CPC range ILLUSTRATIVE)
  Reach ceiling: 21,000,000–26,000,000 reachable users (projection; ILLUSTRATIVE)

No campaign has been created. This is a dry-run draft.

Ready to launch? Hand this payload to `tt4b-launch-traffic-campaign`
(or the matching launch skill).
```

    Data source:      B1–B4 outputs + user inputs (USD 20/day, US, product info); schemas read from campaign_create/adgroup_create definitions
    Confidence:       medium — every field source-tagged; cold account, no delivery history
    Known limits:     CPC range is market-level, not account-level; all claims merchant-asserted
    If degraded, why: not degraded

---

**User:** Looks great — just create it for me.

**Skill:** This skill never creates campaigns — it is the decision layer. Your packet above
is launch-ready. To execute it, use `tt4b-launch-traffic-campaign` (or the matching launch
skill) and hand it this payload.

(No write tool was called at any point in this run — `campaign_create` and `adgroup_create`
were contacted only as readable schema metadata in B5. An explicit user instruction does
not override the read-only contract.)
