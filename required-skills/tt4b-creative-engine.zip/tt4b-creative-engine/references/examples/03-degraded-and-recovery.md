# 03 — Degraded run & recovery (restricted account, partial API failures)

> ILLUSTRATIVE EXAMPLE — all data synthetic (ACME-DEMO tokens). Not real account data.

Shows the resilience contract end to end: E107 continues read-only, E104 surfaces the
raw code and keeps delivering, E201 retries exactly once with the fixed strategy, and
the A3 40002 branch switch. Per-stage disclosure blocks are condensed here; the packet
block is shown in full.

---

## Part 1 — Mode B on a restricted account (ACME-DEMO-003)

**User:** My account just got limited, but I still need a launch plan for my GlowMist
face serum in the US. Hydrating, fragrance-free, USD 24. What should my first campaign be?

**Skill:** Running S0 preflight.
- `bc_get` → 0 Business Centers — not a stop; falling through the discovery ladder
- `auth_advertiser_get` → 1 advertiser: ACME-DEMO-003 ("ACME Demo Beauty") — proceeding
- `advertiser_info_get` (ACME-DEMO-003) → `status: "STATUS_LIMIT"` ≠ STATUS_ENABLE
- `identity_get` (identity_type=TT_USER) → empty → fallback `identity_get` (identity_type=CUSTOMIZED_USER) → empty
- `campaign_get` → 0 campaigns · `report_integrated_get` (campaign-level, LIFETIME) → 0 rows · `catalog_get` → no catalog

**E107_ACCOUNT_RESTRICTED** — ACME-DEMO-003 is `STATUS_LIMIT`, not STATUS_ENABLE.
Appeal path: Ads Manager → Account Status → submit an appeal with business
verification documents. **Read-only analysis continues** — only the future launch
hand-off is marked blocked. Also noted: no usable identity (TT_USER, then
CUSTOMIZED_USER both empty) — the launch hand-off will require an identity.

**Entering Mode B (cold start). Basis: campaign=0, report rows=0, no catalog.
Say so to force Mode A.** Proceeding immediately.

**Skill:** B1 market demand (condensed).
- `tool_search_keyword_idea_get` (seeds "serum", "hydrating", "skincare"; region US) → 14 keywords; top: "face serum" — vol 100K–1M (ILLUSTRATIVE), competition MEDIUM, CPC USD 0.50–USD 1.10 (ILLUSTRATIVE), 3-mo trend +9% (ILLUSTRATIVE)
- `tool_search_keyword_recommend` (top 2 seeds) → 6 adjacent terms added to the matrix

Bid anchor = the B1 CPC range USD 0.50–USD 1.10 (ILLUSTRATIVE). `tool_bid_recommend` is
disabled (returns a constant USD 1 on cold accounts) and was not called.

**Skill:** B2 audience profile + reach — one dimension per call, fixed serial order.
- `audience_insight_info_get` (dimension=age, US) → 25–34: 38%, 18–24: 31% (ILLUSTRATIVE)
- `audience_insight_info_get` (dimension=top_interests, US) → **HTTP 500** — `{"code": 50000, "message": "Internal Service Error"}` (ILLUSTRATIVE)

**E104_PARTIAL_API_FAIL** — interest insight **unavailable**. Raw platform response
surfaced verbatim: HTTP 500, code 50000, "Internal Service Error". This is a hard
failure, not an empty result, so the E201 retry does not apply — no retry. The
run continues on the age dimension alone.
- `ad_audience_size_estimate` (US + age 18–34; no interest filter — degraded) → 9,200,000–11,800,000 reachable users (ILLUSTRATIVE) — reported as a range, never collapsed

**Skill:** B3 targeting package.
- `tool_interest_keyword_recommend_search` (single-word seeds "serum", "skincare"; OR) → 23 raw hits → LLM post-filter kept 12 relevant IDs, discarded 11 fuzzy hits (ILLUSTRATIVE)
- `tool_hashtag_recommend_search` (seed "glow serum") → `code 0`, empty array — silent empty

**E201_EMPTY_RESULT** (hashtag). Fixed strategy for this tool: split multi-word
seeds + force OR. Exactly ONE retry:
- `tool_hashtag_recommend_search` (seeds "glow", "serum"; OR forced) → 9 hashtags → post-filter kept 6, discarded 3 (ILLUSTRATIVE)

Recovered on the single permitted retry. Had this also returned empty, the section
would have been disclosed as empty and degraded — never looped, never fabricated.

**Skill:** B4 creative brief (condensed).
- Hook matrix ranked by volume × growth × inverted competition; top hook angle: "hydration without fragrance" (evidence: "face serum" + "fragrance free serum" B1 rows). All product claims tagged `merchant-asserted` — no catalog exists to verify against. Do-Not-Say list labeled `policy-derived, not account-derived` (no review history on this account).
- `creative_cta_recommend_get` (objective TRAFFIC) → "SHOP_NOW", "LEARN_MORE" (ILLUSTRATIVE) — tool-sourced
- `file_video_ad_search` → 0 videos in asset library → `file_video_suggestcover_get` skipped. Disclosed: no videos in asset library, cover suggestion skipped.

**Skill:** B5 — campaign starter packet (full, degraded honestly).

```
[DRY_RUN_PREVIEW] Campaign starter packet — ILLUSTRATIVE, not real account data

Advertiser: ACME-DEMO-003 · Mode B · 2026-06-15 (ILLUSTRATIVE)

| # | Field                | Value                                     | Source        | Schema-validated |
|---|----------------------|-------------------------------------------|---------------|------------------|
| C1| objective_type       | TRAFFIC                                   | default       | ✓ |
| C2| campaign_name        | glowmist-US-20260615-traffic              | derived       | ✓ |
| C3| budget_mode          | BUDGET_MODE_INFINITE                      | default       | ✓ |
| G1| campaign_id          | — (assigned by campaign_create at launch) | unavailable   | ✗ missing required: campaign_id |
| G2| optimization_goal    | CLICK                                     | default       | ✓ |
| G3| bid_price            | USD 0.80 (B1 CPC midpoint, ILLUSTRATIVE)     | derived       | ✓ |
| G4| budget (daily)       | USD 25.00 (ILLUSTRATIVE)                     | user provided | ✓ |
| T1| interest_keyword_ids | [910001, 910002, …12 ids] (ILLUSTRATIVE)  | tool returned | ✓ |
| T2| hashtag keyword IDs  | [820001, …6 ids] (ILLUSTRATIVE)           | tool returned | ✓ |
| K1| hook                 | "Hydration without the perfume cloud"     | derived       | n/a (creative) |
| K2| CTA                  | SHOP_NOW                                  | tool returned | n/a (creative) |
| K3| identity             | — none usable                             | unavailable   | n/a (creative) |

Projections (arithmetic on real inputs — not guarantees):
  Daily clicks: USD 25 ÷ USD 1.10 ≈ 23 … USD 25 ÷ USD 0.50 = 50 → 23–50 clicks/day
                (projection; CPC range ILLUSTRATIVE)
  Reach ceiling: 9.2M–11.8M reachable users (projection; ILLUSTRATIVE;
                 degraded — estimated without interest filter, see E104 above)

LAUNCH BLOCKED — account restricted (STATUS_LIMIT). Appeal path: Ads Manager →
Account Status → submit appeal. This dry-run packet remains valid; launch
requires a healthy account.
LAUNCH BLOCKED — no usable identity found (TT_USER, then CUSTOMIZED_USER both
empty). The launch skill will need an identity before creating ads.

No campaign has been created. This is a dry-run draft.

Ready to launch? Hand this payload to `tt4b-launch-traffic-campaign`
(or the matching launch skill).
```

---

## Part 2 — Mode A snippet: the 40002 Smart+ branch switch (ACME-DEMO-004)

**User:** On my other account, is "dermatologist tested" safe to put in the new ad?

**Skill:** A3 rejection-history cross-check. The top winner ACME-DEMO-AD-310's ad
type is ambiguous in the A1 context → trying the regular branch first.
- `ad_review_info_get` (ad ACME-DEMO-AD-310) → error `40002 "This API does not support Upgraded Smart Plus ads"`
- Wrong branch — switching, not aborting:
- `smart_plus_ad_review_info_get` (ad ACME-DEMO-AD-310) → 1 rejection on record: rejection_reason "Unsubstantiated medical/health claim" (ILLUSTRATIVE)

Ledger row: "dermatologist tested" → status **blocked**, confidence Medium —
semantic match to past rejection_reason "Unsubstantiated medical/health claim"
(ad ACME-DEMO-AD-310, ILLUSTRATIVE). Safer rewording: "formulated for sensitive
skin", with the merchant's test documentation held as evidence. Rejection history
was never marked "unavailable" on the 40002 — the Smart+ endpoint answered.

---

## Closing disclosure (the degraded Part 1 run, stated honestly)

```
Data source:      bc_get, auth_advertiser_get, advertiser_info_get, identity_get
                  (TT_USER → CUSTOMIZED_USER), campaign_get, report_integrated_get,
                  catalog_get, tool_search_keyword_idea_get, tool_search_keyword_recommend,
                  audience_insight_info_get (age OK; top_interests failed),
                  ad_audience_size_estimate, tool_interest_keyword_recommend_search,
                  tool_hashtag_recommend_search (×2: empty, then split+OR retry),
                  creative_cta_recommend_get, file_video_ad_search + user inputs
Confidence:       medium — keyword and reach data are live; audience interests missing
                  and all product claims merchant-asserted (no catalog)
Known limits:     no interest dimension in B2; no identity; no videos so no cover
                  candidates; account restricted so launch hand-off blocked
If degraded, why: E107 (STATUS_LIMIT — read-only continued, launch blocked) ·
                  E104 (audience_insight_info_get top_interests → HTTP 500 code 50000
                  "Internal Service Error", no retry, section item unavailable) ·
                  E201 (hashtag first call code 0 + empty; one retry with split
                  multi-word seeds + forced OR → recovered)
```
