# 最小输入与证据账本

不是要客户填写的完整表单。优先复用对话、当前授权绑定与已读结果；必要且合适的已核只读工具要先尝试。无法获取的具体经营事实才最小追问。

| 输入 | 获得顺序 | 何时真正必要 |
|---|---|---|
| 客户目标、市场、品类、受众使用任务 | 明示上下文；不明则问最小项 | 每案，不能由账户注册国代替客户市场 |
| 账户及对象 | 当前授权绑定 → auth_advertiser_get → 用户只选本案账户；ad_get 解析关联 | 账户广告评审；纯客户草稿不必连接账户 |
| 图片/视频素材 ID | 本案明确 ID 或 ad_get 实际结果 | 不用名称猜 ID，不采集全库 |
| 可观察内容 | 已核素材搜索结果中实际可读媒体 → 客户授权的关键图/帧/脚本 | 内容判断；无读取能力不能说“视频开头不好” |
| 尺寸/安装条件/真实价格/材质/清洁或环保承诺 | 当前包没有已核商品事实接口；复用客户确认数据，必要时只问相关缺项 | 只有建议要使用这项事实时；图片比例不能测量实物尺寸 |
| 改造费用及范围 | 复用客户确认的金额、币种和包含项目；只补与当前表达有关的缺项 | 只有费用表述在本次内容任务中时；局部商品价格不能推成整屋成本 |
| 观众下一步与目的地 | 已给客户目标及可验证的内容/入口；不足时最小确认 | 只有评审行动提示时；读到结尾或完整脚本才能判缺失，不自行创造购买渠道 |
| 客户指标、期间、风险约束 | 已给目标与客户决定；账户报表只给事实不替客户定目标 | 表现比较与实验；不要默认 CTR、ROI、预算或时长 |
| 实际变更 | 可用 operation_log_tool 的相关日志 + 客户确认的经营变更 | 下降归因/改后复查；空日志不能证明无变化 |

每项证据记录：`id, source_kind, observed_at, selected_scope, object_or_asset_id, coverage, fact_or_claim, period/timezone/currency/attribution_if_relevant, value_or_description, missing_fields`。

`source_kind`：approved_read / customer_confirmed / customer_asset_claim / synthetic_test。不得把后两项改写成真实 MCP 结果。

内容阅读状态：metadata_only / text_only / image_observed / selected_frames_observed / full_content_observed。本包未注册完整视频读取能力，不能仅因素材检索成功给出 full_content_observed。客户材料只有文件名/不可读附件不是读取其广告账户的授权；仅在用户要求账户证据时激活账户链。复查另外记录new_version_identity、本轮已取证/阻断状态和return_step，旧版本ID不自动复用为新版本，避免不可读时重复循环。

工具账本逐案记录 required（条件+必要性）/ optional / completed（响应状态+证据ID）/ failed / unattempted（blocked_not_attempted原因）。空结果单列，尝试覆盖与可用证据覆盖分开；纯客户草稿无核心工具则 N/A，不能计 100% 成功。
