# Read-only tool contract

运行前读 [请求范围](read-profiles.json)，并核当前宿主完整定义。只限本案最小只读范围；本地契约不是绑定或真实成功证明。

## Applicable tool plan

| Task | Required only when condition applies | Optional / not a substitute |
|---|---|---|
| Provided draft or customer media | No account tool required; use read content and confirmed facts; a filename or unreadable attachment goes to a minimal content request, not automatic account discovery | No meaningless account call to increase invocation rate |
| Existing account ad content | T0 if binding missing; T2 if object/material association missing; T3/T4 for relevant image/video IDs not yet retrieved | Metadata is not semantic media analysis |
| Performance question | T5 when correctly bound; T6 only for the supported equivalent spend/exposure question; T1 when timezone/currency missing; T7 when change history is needed and bound | T6 campaign totals cannot replace asset CTR/ROI or causality |
| Post-change review | Resolve the actual new version via T2 only if account evidence was requested and new material association is missing; then only applicable content and metric tools for the agreed window; T7 if needed | Old identity is not the new version; reuse this-run completed/blocked evidence rather than repeatedly following the same loop |

Before answering, compare required/completed/failed/unattempted. A safe, available, parameter-complete necessary call must be attempted. Missing auth, scope, identity or schema stays `blocked_not_attempted`; it is not an attempted/successful call. Empty responses are distinct from usable evidence. For an error, at most one retry after correction grounded in the confirmed schema or a transient failure; stop authorization errors. Do not switch accounts or broaden scope. An alternate must provide the same object, granularity, metric and window; otherwise label it a narrower partial result.

## T0 auth_advertiser_get

- Native adapter input `{}`; returns IDs/names authorized by the current session. Invoke only when an account is genuinely needed but not bound/provided.
- Raw REST catalog lists app_id/secret; current MCP definition deliberately accepts no parameters and handles authorization. Do not transfer REST credentials into the MCP call or ask the customer for them. If the target lacks this verified adapter, stop for connection setup.
- Use only an unambiguous intended account. Multiple results require a minimal choice, not automatic use of the first or calls against all accounts. Do not expose the full customer list. No result does not prove a shop or account does not exist.

## T1 advertiser_info_get

- Required `advertiser_ids:string[]`, here exactly the selected one. Pass minimal `fields:["advertiser_id","currency","timezone"]` when needed.
- Do not omit fields and retrieve contact/license/address/balance data. Special fields company_name_editable/can_use_custom_identity/ads_only_mode cause ordinary fields to be ignored; do not mix them here.
- Only use returned timezone/currency; advertiser country is not the customer's target market. No write/partner-creation operation mentioned in its descriptive cross-reference is allowed.

## T2 ad_get

- Required `advertiser_id:string`. Use known `filtering.ad_ids`, `adgroup_ids`, `campaign_ids` or `ad_ids_v2` (max 100 each) to constrain the request. If only a name is known, read only the selected permitted account scope and resolve it from returned records; do not invent a name filter.
- Page default 1, page_size default 10, valid 1–1000. Follow returned page_info within selected scope. Do not assume one page is the entire ad universe. Do not suppress null fields when needed to expose missing evidence.
- Default origins TT_ADS_PLATFORM; Promote returns only limited identity/status fields. Default buying types AUCTION and RESERVATION_RF; RESERVATION_TOP_VIEW cannot be combined with others. This skill does not add TopView/Promote or other objective/destination filters without matching customer scope and confirmed supported combinations.
- Deleted ads excluded by default. Querying a specifically relevant deleted ad requires the documented status filter and a permitted current runtime; no invented status enums.
- `ad_ids_v2` for Upgraded Smart+ can return only object/name/automation fields, not complete material evidence. Smart Creative requires a separate material endpoint not contracted here. Shop-created Product/LIVE GMV Max data is excluded by the catalog response note. Treat all as coverage limitations; do not fill missing asset IDs from names.
- Date filters for creation/modification are UTC timestamps, not ad-report local dates. Omit unless required by scope; keep documented recommendations distinct from hard range constraints. Objective WEB_CONVERSIONS/CONVERSIONS filtering returns both, so check actual returned objective.
- Accept actual list/page_info, object IDs, text, asset associations and statuses only if returned; no field is assumed merely from a typical response. Ad text is a claim, not verified physical product fact.

## T3 file_image_ad_search

- Required advertiser_id. Use `filtering.image_ids` or `material_ids` from the current customer/approved read, max 100 each. `filtering` is an object in actual inputSchema, not the catalog prose's loose “array” description.
- page ≥1; page_size 1–100, defaults 1/20. First 10,000 images ordered by modify_time only. Follow page_info for the requested bounded result, never claim complete library coverage beyond the cap.
- Optional displayable defaults false. This package omits width/height/ratio filters; image dimensions cannot establish product physical size.
- The catalog promises image information, not a specific retrievable media URL or visual interpretation. Only actual visible image evidence may support content statements. Failed media viewing means metadata-only, not observed image.

## T4 file_video_ad_search

- Required advertiser_id; filtering object. `video_ids` max 100, `material_ids` max 20. Prefer known IDs. video_name is fuzzy search, so matching name alone is not object identity.
- Videos unusable in ads may be ignored. When video_ids is omitted, repeated uploads may collapse to one valid ID; results include only the latest-modified 10,000. Empty results cannot prove there is no creative, no authorization, or a content problem.
- page ≥1, page_size 1–100, defaults 1/20. Do not send sort_field or deprecated height/ratio/width/displayable video parameters. This package omits video_material_sources; exact selected-asset filtering is sufficient for its task.
- Output list/page_info describes videos; it does not guarantee transcript, OCR, audio, video frames, playback, or semantic analysis. Do not call a video reviewed merely because metadata or a cover image was returned. No removal of ID filters to bypass empty/failed results.

## T5 planning_reporting

- Schema required: query:string and ttamAccountID:string. Other possible fields: sessionID, target_language, userID, all strings.
- Query ≤50 words, preserve the customer's original demand and add only essential known time, objective and object context. Do not add unrequested metrics to a generic performance question. ttamAccountID from selected authorized account; userID/sessionID only authenticated host values, omit if absent.
- Match the user's supported language: en/id/ms/zh/th/vi/ar/tr/it/de/fr/es/pt/ru/ja/ko/pl-PL/sv-SE/cs-CZ. For Chinese use zh, not an arbitrary English default.
- Description supports read settings and delivery reporting/aggregation. Current target binding and read-only downstream chain must still be verified. No output schema is supplied: only accept actual scoped metrics with period, definitions and coverage; do not assume list/metrics keys or complete results. No documented pagination parameter.
- Missing target binding disables T5, not all content analysis. T6 is an alternative only for its narrow directly supported spend/exposure case. Customer aggregates after suitable retrieval is unavailable must be labeled customer-provided, not MCP evidence.

## T6 report_integrated_get

This package binds only one narrow documentation-supported request profile, not arbitrary metric combinations:

```json
{
  "advertiser_id": "<selected authorized ID>",
  "report_type": "BASIC",
  "data_level": "AUCTION_CAMPAIGN",
  "dimensions": ["campaign_id"],
  "filtering": [{"field_name":"campaign_ids","filter_type":"IN","filter_value":"[\"<selected actual campaign ID>\"]"}],
  "start_date": "<customer-agreed YYYY-MM-DD>",
  "end_date": "<customer-agreed YYYY-MM-DD>"
}
```

- This profile is for an actual supported auction campaign, same selected account, spend/exposure context. Omitted metrics use the documented BASIC default spend/impressions. No CTR, clicks, conversion, ROI, product/item or video dimension is added without separately verified compatibility. If only an ad-level question is meaningful, do not substitute campaign totals.
- Supported dimension/metric/filter combinations are not proven by a generic string schema. A target definition or validated documentation conflicting with this profile blocks it; never brute-force combinations. The source explicitly describes ID batching and campaign_id grouping; this is documentation validation, **not a successful live request**.
- Natural-language required fields: BASIC needs advertiser_id (not bc_id), data_level; non-lifetime queries need both dates using ad-account timezone. One account only; no advertiser_ids/multi-account totals. Timezone missing → T1 before calling. Date range ≤365 days without a time dimension; this profile has no daily/hourly/lifetime breakdown. No query_mode or deprecated service enum.
- Filtering requires field_name/filter_type/filter_value together. IN values are a JSON-array **string**, not an array. Selected ID batches max 100; current profile normally one. Never use material/video IDs as campaign IDs.
- page default 1, page_size default 10, range 1–1000; follow actual page_info only in scope. Synchronous reports truncate at 20,000 advertisements even when totals enabled; narrow approved ID batches if relevant, otherwise declare partial. No automatic async job creation (write) or scope expansion.
- Default campaign status excludes deleted campaigns. Record covered status. A sync report is not a reliable direct reconciliation partner for TTAM downloaded reports; route that reconciliation elsewhere, do not call it an attribution fault.
- No structured output table is provided in the catalog. Require real returned campaign ID, metric labels/values and window consistency. Missing/null/empty ≠ zero; spend=0 creates undefined spend-based ratios. Aggregation at campaign level cannot attribute performance to a specific home scene or material.

## T7 operation_log_tool

- Required adv_id:string, user_id:string, lang:string. Values from selected authorized account and authenticated host. A missing user_id cannot be invented or replaced by advertiser ID.
- Optional campaign_id/adgroup_id/creative_id from selected object/approved read; start_time/end_time YYYY-MM-DD. Defaults are seven days ago/current date, but for comparison pass the actual agreed window rather than silently changing it.
- Read history only; descriptions of creation/budget/status changes describe records, not authorization to repeat the operations. There is no structured output/pagination schema in the source; accept actual records and coverage, not imagined old/new fields.
- Missing binding, permission or identity → blocked; empty logs ≠ no changes. Business price/stock/promotion changes may remain outside returned ad logs.

## Shared evidence and answer contract

Preserve source, retrieved time, authorized scope, object/material identity, period/timezone/currency/attribution if relevant, exact metric or observed content, coverage and missingness. Match those fields before comparison. Aggregate numerators/denominators rather than averaging ratios. Failed/partial content retrieval cannot support whole-video conclusions; before/after performance does not establish causality.

After all appropriate safe retrieval is attempted or specifically blocked, ask only for needed customer-confirmed facts or the missing aggregate. No raw consumer PII, credentials, entire customer lists or other-account benchmarks. Manual action cards remain proposals with an owner, concrete change, supporting evidence, customer guardrail and review/stop condition; no tool performs the action.
